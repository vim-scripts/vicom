// =====================================================================================
// 
//       Filename:  vcominst.cc
// 
//    Description:  Installation program for the vicom line commenter
// 
//          $Id: vcominst.cc,v 1.5 2010/04/05 09:53:34 mike Exp $
//          $Revision: 1.5 $
// 
//         Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//   Copyright (C) 2006-10 Mike Lear <mikeofthenight2003@yahoo.com>           
//                                                                            
//   This file is free software; as a special exception the author gives      
//   unlimited permission to copy and/or distribute it, with or without       
//   modifications, as long as this notice is preserved.                      
//                                                                            
//   This program is distributed in the hope that it will be useful, but      
//   WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//   implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// 
// =====================================================================================
//
#include    "vicmain.h"
using       namespace edn;
using       namespace edm;
bool        edm::isXterm;


int main() {
XYinstall XY;		
Error <string> E;	
std::string Mode;

		try {
 				Mode = XY->Getenv("TERM");
				Mode == "xterm" ? isXterm = true : isXterm = false;
 				XY->GetUserShell();
				XY->CheckforVimrc();
				XY->CreateVimBuffer();
				XY->WriteVimAlias();

			} catch (const FileError& e) {
					E->Mesg(e.what(),"\n");
					exit (1);
			} catch ( ... ) {
					E->Quit("Unrecognized exception");
					}

		E->Mesg("\n\n\t\t -- INSTALLATION COMPLETED --\n\tvicom is now"
				" ready for use. Close all existing terminals then start a fresh\n\t"
				"terminal or logout and log back in again. This will make the aliases active."
				"\n\tFor further information read the html document in the doc subdir.\n");

return 0;
}
