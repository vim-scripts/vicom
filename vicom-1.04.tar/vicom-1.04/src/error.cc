// =====================================================================================
// 
//       Filename:  error.cc
// 
//    Description:  Methods for the error class used in the Vim-Gvim Make Utility.
//
//         $Id: error.cc,v 1.3 2010/04/05 09:53:34 mike Exp $
//         $Revision: 1.3 $
// 
//          Author:  Mike Lear 
//          Copyright (C) 2006-09 Mike Lear <mikeofthenight2003@yahoo.com>   
//                                                                            
//          This file is free software; as a special exception the author gives      
//          unlimited permission to copy and/or distribute it, with or without       
//          modifications, as long as this notice is preserved.                      
//                                                                            
//          This program is distributed in the hope that it will be useful, but      
//          WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//          implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// =====================================================================================
//
#include "error.h"
namespace edm{
extern bool isXterm;	
using namespace edn;


RunTimeError::RunTimeError(const string& fileNameIn) : FileError(fileNameIn) 
{
			ostringstream ostr;
			isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
			ostr << "A runtime failure occurred with " << fileNameIn << endl; 
			_Mesg = ostr.str();
}

FileIndexError::FileIndexError(const string& fileNameIn) :	FileError(fileNameIn)
{
			ostringstream ostr;
			isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
			ostr << "Bad index whilst checking for file suffix on " << fileNameIn << endl;
			_Mesg = ostr.str();
}

FileCreateError::FileCreateError(const string& fileNameIn) : FileError(fileNameIn) 
{
			ostringstream ostr;
			isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
			ostr <<  "Unable to create " << fileNameIn << endl;
			_Mesg = ostr.str();
}

FileCloseError::FileCloseError(const string& fileNameIn) : FileError(fileNameIn) 
{
			ostringstream ostr;
			isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
			ostr <<  "Unable to close " << fileNameIn << endl;
			_Mesg = ostr.str();
}

FileOpenError::FileOpenError(const string& fileNameIn) : FileError(fileNameIn) 
{
			ostringstream ostr;
			isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
			ostr <<  "Unable to open " << fileNameIn << endl;
			_Mesg = ostr.str();
}

FileSeekError::FileSeekError(const string& fileNameIn) : FileError(fileNameIn) 
{
			ostringstream ostr;
			isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
			ostr <<  "Seek failed on " << fileNameIn << endl;
			_Mesg = ostr.str();
}

FileWriteError::FileWriteError(const string& fileNameIn) :	FileError(fileNameIn)
{
			ostringstream ostr;
			isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
			ostr << "A write error occurred in file " << fileNameIn << endl;
			_Mesg = ostr.str();
}

FileReadError::FileReadError(const string& fileNameIn) : FileError(fileNameIn)
{
			ostringstream ostr;
			isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
			ostr  << "A read error occurred in file " << fileNameIn << endl;
			_Mesg = ostr.str();
}

BadFileName::BadFileName(const string& fileNameIn) :	FileError(fileNameIn)
{
			ostringstream ostr;
			isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
			ostr <<  fileNameIn << ": Bad filename in build list!" << endl;
			_Mesg = ostr.str();
}

FileAppdError::FileAppdError(const string& fileNameIn) : FileError(fileNameIn)
{
			ostringstream ostr;
			isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
            ostr <<  "Unable to append to " << fileNameIn << endl;
			_Mesg = ostr.str();
}

FileStatError::FileStatError(const string& fileNameIn) : FileError(fileNameIn)
{
			ostringstream ostr;
			isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
			ostr <<  "Stat failed on " << fileNameIn << endl;
			_Mesg = ostr.str();
}

FileUnknownError::FileUnknownError(const string& fileNameIn) :	FileError(fileNameIn)
{
			ostringstream ostr;
			isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
			ostr <<  "Unknown or invalid file-suffix " << fileNameIn << "?" << endl;
			_Mesg = ostr.str();
}

FileEnvError::FileEnvError(const string& fileNameIn) :	FileError(fileNameIn)
{
			ostringstream ostr;
			isXterm == true ? ostr << TabRed : ostr << nTab << "Error: ";
			ostr <<  fileNameIn << " not in the env path!" << endl;
			_Mesg = ostr.str();
}

} // edm namespace
