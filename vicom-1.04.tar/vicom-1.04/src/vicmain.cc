// =====================================================================================
// 
//       Filename:  vicmain.cc
// 
//    Description:  Source code for the Linux Version of the Vim-Gvim auto-commenter utility.
//                  Comments compatible with source program are loaded at start time.
//                  Allowing commenting or uncommenting from the same keys.                         
//
//         $Id: vicmain.cc,v 1.5 2010/04/04 18:22:56 mike Exp $
//         $Revision: 1.5 $
// 
//          Author:  Mike Lear 
//          Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>   
//                                                                            
//          This file is free software; as a special exception the author gives      
//          unlimited permission to copy and/or distribute it, with or without       
//          modifications, as long as this notice is preserved.                      
//                                                                            
//          This program is distributed in the hope that it will be useful, but      
//          WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//          implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
//
// =====================================================================================
//
#include "vicmain.h"
namespace   edm {
extern bool isXterm;
using  namespace edn;





//=======================================================================
//		Constructor:
//=======================================================================
XYkeys::XYkeys() {
Error <string>E;
struct passwd *pw;

        if (!(getuid()))
            E->Quit("vcominst should not be run as root\n");

        if (!(pw = getpwuid(getuid())))
            E->Quit("Can't get user's password information!\n");
            endpwent();
            _HomeDir   = pw->pw_dir;
            _UserShell = pw->pw_shell;


}


//=======================================================================
//		GetAsmExtType  
//		Test assembly source file to determine if its written in Intel or At&t
//		code. This determines commment type to use.
//=======================================================================
bool XYkeys::GetAsmExtType(std::string &InFileName) {
struct 		stat statbuf; 
std::auto_ptr<string>  srcode(new string(".globl"));
std::auto_ptr<string>  inFile(new string(InFileName));
std::ofstream fout;
bool 		result = false;

			//---------------------------------------------------------------------------
			// If file does not yet exist return nasm comment as option.
			//---------------------------------------------------------------------------
		if (stat((*inFile).c_str(),&statbuf) < 0){ 
			return result;
		}
		
			//---------------------------------------------------------------------------
			// If file is empty return nasm comment as option
			//---------------------------------------------------------------------------
		if (!statbuf.st_size) {
			return result;
		}
		
			//---------------------------------------------------------------------------
			// Scan file for AT&T code if found return true
			//---------------------------------------------------------------------------
			ifstream fin((*inFile).c_str());
		if (fin.fail()) {
			throw FileOpenError((*inFile).c_str());
			}
			result = Strstr((*inFile).c_str(),(*srcode).c_str());
			fin.close();

return  result;
}

//=======================================================================
//		AdjAsmExt  Adjust index's for file extenstions over 4
//		This is to make it compatible with the vimake's GetFileExt
//=======================================================================
int XYkeys::AdjAsmExt(unsigned int idx) {

		switch (idx) { 
		case 1:
		case 2:
		case 3:
		case 4:		break;
		case 5:		idx -= 4;
					break;
		case 6:
					idx -=3;
					break;
		default:    break;
		}

return (idx);		
}


//=======================================================================
//		WriteVimrcFile  Writes suitable comment keys in the .vimrc buffer
//		determined by source file being edited. Non program files clear
//		the .vimrc buffer disabling the comment function.
//=======================================================================
int XYkeys::WriteVimrcFile(unsigned int mode) {
Error <string>E;      
_comment  med;
std::fstream FinOut;        
std::ifstream inFile;       
std::auto_ptr<unsigned> cmpbuf(new unsigned);
std::auto_ptr<string> rwBuffer(new string);
std::auto_ptr<string> vimfile(new string(_HomeDir));
std::auto_ptr<string>  xyfile(new string(_HomeDir));

				(*vimfile).append("/.vimrc");			
				(*xyfile).append("/bin/xydata.bin");

				inFile.open((*xyfile).c_str(),ios_base::in|ios_base::binary);       
		if (inFile.is_open()) {
				inFile.seekg(0);
			//---------------------------------------------------------------------------
			//		Check that the current .vimrc has a 512byte buffer
			//---------------------------------------------------------------------------
			FinOut.open((*vimfile).c_str(),ios_base::in|ios_base::out|ios_base::binary);       

		if (FinOut.fail()){
		throw 	FileOpenError((*vimfile).c_str());
				}
		if (FinOut.is_open()) {  
				FinOut.seekg(BufferSize,std::ios_base::beg);           
				getline(FinOut,*rwBuffer);      					
				*cmpbuf = warn.compare(11,7,*rwBuffer,0,7);                    
		if (*cmpbuf != 0) {            
				FinOut.close();
				E->Quit("vicom has not been configured yet!\n",
						"\t\trun 'vcominst' first.\n");
			}
		} else {
				FinOut.close();
				throw FileReadError((*vimfile).c_str());                      
				}
			//---------------------------------------------------------------------------
			//		Buffer exists so clear it first.
			//---------------------------------------------------------------------------
			(*rwBuffer).clear();
			(*rwBuffer).append(BufferOffset,' ');				
			FinOut.seekp(0,std::ios_base::beg); 			
			FinOut << *rwBuffer  << std::flush; 					 
			FinOut.seekp(std::ios_base::beg);

		if (inFile.is_open()) {                               			
		  	inFile.seekg(0);


  		if (inFile.fail()){
			throw FileSeekError((*xyfile).c_str());
			}   
			//---------------------------------------------------------------------------
			//		Leave the buffer blank if its not a program file. Otherwise write
			//		the new commenter strings to the buffer.
			//---------------------------------------------------------------------------
			if (mode > 0 && mode < 5) {								
			std::streampos pos_type = mode * sizeof med;                   
			inFile.seekg(pos_type);
			inFile.read((char *) &med,sizeof med);						
		  	FinOut  << med.nameNL << endl << med.nameX << endl << med.nameIX << endl;
			FinOut  << med.nameIY << endl << med.nameY << endl << med.nameB << endl << med.nameT << endl;
			}
			inFile.close();
			FinOut.close();

		if (inFile.eof()) {
				inFile.clear(); 
				throw FileReadError((*xyfile).c_str());
				}    
		 	 }  
		   }   

					inFile.close();
			if (!FinOut.eof()){
					FinOut.flush();
					FinOut.close();
			} else { 
					FinOut.close();
			throw   FileWriteError((*vimfile).c_str());
			}

return(0);
}
} // ns


