// =====================================================================================
// 
//       Filename:  vicom.cc
// 
//    Description:  Source code for the Linux Version of the Vim-Gvim auto-commenter utility.
//                  Comments compatible with source program are loaded at start time.
// 					Allowing commenting or uncommenting from the same keys. 	                    
//
//         $Id: vicom.cc,v 1.4 2010/04/04 18:22:56 mike Exp $
//         $Revision: 1.4 $
// 
//          Author:  Mike Lear 
//          Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>   
//                                                                            
//          This file is free software; as a special exception the author gives      
//          unlimited permission to copy and/or distribute it, with or without       
//          modifications, as long as this notice is preserved.                      
//                                                                            
//          This program is distributed in the hope that it will be useful, but      
//          WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//          implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
//			______________________________________________________________________
//
//     		NOTE:                                                                    
//     		If you examine the aliases installed in any of the shell configuration   
//     		files you will see that there are two hypens following the word -mvim    
//     		or -mgvim.  // ie: 	alias vi='vicom -mvim -- ' 			               
//     		It is important NOT to remove these hypens as they are there to prevent 
//     		the "getopt" function in this program from parsing past them.
//     		This then allows options entered to be passed untouched by vicom to the 
//     		Vim or Gvim editor.  
//
// =====================================================================================
//
#include 	"vicmain.h"
using 		namespace edn;
using 		namespace edm;
bool    	edm::isXterm;


int main(int argc,char *argv[]) {

Error<string> 			E;
XYkeys XY;

ostringstream 			ost;
string::size_type 		idx,index;
auto_ptr<string>  		Editor(new string);      
auto_ptr<string>  		FileSuffix(new string);  
auto_ptr<int signed>  	Status(new int signed);
auto_ptr<string> 		VimPath(new string);
string 					Mode;
bool 					result=false;



              try {
						Mode = XY->Getenv("TERM");
						Mode == "xterm" ? isXterm = true : isXterm = false;

				if (argc < 2)
						E->Quit(msg2.c_str());

							//------------------------------------------------------------------
							//  	Determine if vim or gvim called
							//------------------------------------------------------------------
						opterr = 0;
				while ((*Status = getopt(argc, argv, "m:")) != -1) { 

				switch (*Status) {					 		
						case 'm': 	(*Editor).append(optarg);	 		
									break;
						case '?': 	E->Quit(msg1.c_str()); 
									break;
								}
						}
							//------------------------------------------------------------------
							//		Get env path to vim or gvim
							//------------------------------------------------------------------


							 *VimPath = XY->Getenvpath(*Editor);
							ost << *VimPath;  							
				for (*Status=optind; *Status < argc; ++(*Status)) 	 
							ost  << " " << argv[*Status]; 	      	
							*Editor = ost.str();					
							index = (*Editor).rfind("."); 

							//------------------------------------------------------------------
							//		Determine source file type and create suitable index
							//------------------------------------------------------------------
				if (index != string::npos) { 		 		 
							(*FileSuffix).assign(*Editor,index,(*Editor).size()); 
							
							index = XY->GetFileExt((*FileSuffix).c_str());  	 		
							index = XY->AdjAsmExt(index);                  

							//------------------------------------------------------------------
							//		Adjust index only on AT&T or Intel source assembly files 
							//------------------------------------------------------------------
				if (index == 3) {
							idx = (*Editor).rfind(" ");   		

				if (idx != string::npos) { 		 		 
							(*VimPath).assign(*Editor,idx+1,(*Editor).size()); 
							result = XY->GetAsmExtType(*VimPath); // *VimPath = showf.asm	
							}

				if (result) index -= 2;	  
								}
							}

							//------------------------------------------------------------------
							//		Write suitable comments to .vimrc buffer or clear buffer
							//		if file is not a recognized program source file.
							//------------------------------------------------------------------
							XY->WriteVimrcFile(index);    		 		
							XY->Runcmd(*Editor);				 		
				} catch (const FileError& e) {
							E->Mesg(e.what());
				} catch ( ... ) {
							E->Quit("Unrecognized exception");
						}

exit(0);
}


