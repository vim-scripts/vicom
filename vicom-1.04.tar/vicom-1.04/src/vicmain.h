#ifndef __VICMAIN__H
#define __VICMAIN__H
// =====================================================================================
// 
//       Filename:  vicmain.h
// 
//    Description:  Header File for the Vim auto commentor class
// 
//          $Id: vicmain.h,v 1.6 2010/04/04 18:22:56 mike Exp $
//          $Revision: 1.6 $
// 
//         Author:  Mike Lear (motn), mikeofthenight2003@yahoo.com
//   Copyright (C) 2006-10 Mike Lear <mikeofthenight2003@yahoo.com>           
//                                                                            
//   This file is free software; as a special exception the author gives      
//   unlimited permission to copy and/or distribute it, with or without       
//   modifications, as long as this notice is preserved.                      
//                                                                            
//   This program is distributed in the hope that it will be useful, but      
//   WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//   implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// 
// =====================================================================================

//----------------------------------------------------------------------
//      Header and Namespace declarations.
//----------------------------------------------------------------------
#include 	<iostream>
#include 	<sstream>
#include 	<fstream>
#include 	<map>
#include 	<string>
#include 	<vector>
#include 	<memory>
#include 	<algorithm>
#include 	<unistd.h>
#include 	<cstdlib>
#include 	<pwd.h>
#include 	<sys/stat.h>
#include 	<sys/wait.h>
#include 	"utils.h"
#include 	"error.h"

namespace   edn {

using   std::cout;
using   std::cerr;
using   std::endl;
using   std::ends;
using   std::ifstream;
using   std::ofstream;
using   std::fstream;
using   std::ios;
using   std::string;
using   std::vector;
using   std::istringstream;
using   std::ostringstream;
using   std::stringstream;
using	std::auto_ptr;

}
namespace   edm{
extern bool isXterm;
using   namespace edn;
void Getalias(std::string &str);
string Which(std::string &str);
const int BufferSize   = 512;
const int BufferOffset = 500;



		class _comment {
			public:
			    char nameNL[20];
				char nameX [100];
				char nameIX[100];
				char nameY [120];
				char nameIY[120];
				char nameB [20];
				char nameT [20];
				};

		class XYinstall : public virtual Utils {
	        protected:
				std::string _HomeDir;
				std::string _UserShell;
			public:
				XYinstall();
				virtual int  GetUserShell(void);
				virtual int  CheckforVimrc(void);
				virtual int  CreateVimBuffer(void);
				virtual void WriteVimAlias(void);
				virtual void FileCopy(std::string &InFileName,std::string &OutFileName);
				XYinstall *operator->() { return this; };
				virtual ~XYinstall() {};
				};

		class XYkeys : public virtual Utils {
				std::string _HomeDir;                    
				std::string _UserShell;                 
			public:
				XYkeys();
				virtual bool  GetAsmExtType(std::string &InFilename);
				virtual int   AdjAsmExt(unsigned int idx);
				virtual int  WriteVimrcFile(unsigned int mode);
				XYkeys *operator->() { return this; };
				virtual ~XYkeys() {};
				};

const std::string warn
    ("\"+-+-+-+-+ WARNING DO NOT EDIT ABOVE THIS LINE +-+-+-+-+ VICOM BUFFER +-+-+-+-+\n"
	 "\" vicom auto program line commenter                mikeofthenight2003@yahoo.com");
const std::string wspce
	(":map <C-W> :%s/\\s\\+$// <CR> <Esc>:w! <CR>|\" Remove tabs & spaces from whitespace");
const std::string msg0(" VCOMINST FAILED\n\t");

const std::string msg1("-- Bad arguments or path --\n\n\t"
	"Getopt cannot determine the arguments passed to vicom, might be a bad\n\t"
	"path or vicom has been run incorrectly. It must be called by either\n\t"
	"vi or gvim. Run 'info vicom' for more information.\n");
const std::string msg2("Vicom should not be run directly.\n\t\tEnsure vcominst has been run first."
	"\n\t\tThen use vi or gvim in the normal manner. \n\n");

} // ns
#endif
