// =====================================================================================
// 
//          $Id: vinstall.cc,v 1.8 2010/04/05 09:53:34 mike Exp $
//          $Revision: 1.8 $
//
//       Filename:  vinstall.cc
// 
//    Description:  Source code for installing the Linux Version of Vicom.
//                  Auto Commenter for the Vimake programmers workbench package                 
//
//          Author:  Mike Lear 
//          Copyright (C) 2006-9 Mike Lear <mikeofthenight2003@yahoo.com>   
//                                                                            
//          This file is free software; as a special exception the author gives      
//          unlimited permission to copy and/or distribute it, with or without       
//          modifications, as long as this notice is preserved.                      
//                                                                            
//          This program is distributed in the hope that it will be useful, but      
//          WITHOUT ANY WARRANTY, to the extent permitted by law; without even the   
//          implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// =====================================================================================
//
#include "vicmain.h"
namespace   edm {
extern 		bool isXterm;
using  		namespace edn;





//--------------------------------------------------------------------------------
//		Constructor: Initialize  Homedir and Usershell.
//--------------------------------------------------------------------------------
XYinstall::XYinstall() {
Error <string>E;	
struct passwd *pw;

		if (!(getuid()))
			E->Quit("vcominst should not be run as root\n");

		if (!(pw = getpwuid(getuid()))) 
			E->Quit("Can't get user's password information!\n");
			endpwent(); 
			_HomeDir   = pw->pw_dir;
			_UserShell = pw->pw_shell;
		

}

//--------------------------------------------------------------------------------
//		Getusershell: 
//		Tests for Shell that user is running. 
//		If there is no $HOME/config file then create a default
//--------------------------------------------------------------------------------
int XYinstall::GetUserShell(){
Error <string>E;	
struct stat statbuf;
std::string::size_type mode;
auto_ptr<string> cfgtype(new string(_UserShell));
std::ofstream fout;    


				(*cfgtype).append("rc");
				mode = (*cfgtype).rfind("/");
				(*cfgtype).assign((*cfgtype),mode,(*cfgtype).size());
				mode = (*cfgtype).rfind("/");
				mode = (*cfgtype).compare(mode,3,"/sh",0,3);
				(*cfgtype).insert(1,".");
				(*cfgtype).insert(0,_HomeDir);
		if  (!mode)
			E->Quit("Bad Shell, vicom will not work with ",(*cfgtype).c_str(),"\n");

		if (stat((*cfgtype).c_str(),&statbuf) < 0) {   
				E->Mesg("\n\t-- Unable to stat ",(*cfgtype).c_str()," so will create. --");
				fout.open((*cfgtype).c_str(),std::ios::out|std::ios::app);    

		if (fout.fail())
				throw FileOpenError((*cfgtype).c_str());
				mode = (*cfgtype).rfind("/");
				(*cfgtype).assign((*cfgtype),mode,(*cfgtype).size());
				(*cfgtype).erase(0,1);
				fout << "# " << *cfgtype << " created by vcominst.\0" << std::endl;  
				E->Mesg("-- Creating  the  file ",(*cfgtype).c_str()," --");
				fout.close();    
				}  

return 0;
}

//--------------------------------------------------------------------------------
//		Checkforvimrc:	
//		If $HOME/.vimrc does not exist create default
//		If $HOME/.vimrc exists create backup 
//--------------------------------------------------------------------------------
int XYinstall::CheckforVimrc() {
Error <string>E;	
struct stat statbuf;
std::string::size_type mode;
auto_ptr<string> vimBuf(new string(_HomeDir));
auto_ptr<string> vimCfg(new string(_HomeDir));
auto_ptr<string> vimDir(new string(_HomeDir));
std::ofstream fout;     
std::ifstream fin; 	    

			(*vimBuf).append("/.vimrc");
			(*vimCfg).append("/.vimrc");
			(*vimDir).append("/vimrc.bak");

		if (stat((*vimCfg).c_str(),&statbuf) < 0) { 	  
	   		mode = (*vimCfg).rfind("/");   		
   			(*vimCfg).assign((*vimCfg).c_str(),mode,(*vimCfg).size());  
			(*vimCfg).replace(0,1,"");  
			E->Mesg("-- Unable to stat file ",(*vimCfg).c_str()," --");
		 	fout.open((*vimBuf).c_str(),std::ios::out|std::ios::app);    

		if (fout.fail()) 
			throw FileOpenError((*vimCfg).c_str());
		
			fout << "\"#	" << *vimCfg << " created by vcominst\n\0" << std::endl;  
			E->Mesg("-- Creating  the  file ",(*vimCfg).c_str()," --");
			fout.close();  
			FileCopy(*vimBuf,*vimDir);
		} else { 		   

		 	fin.open((*vimCfg).c_str(),std::ios_base::in);   	  

		if (fin.fail()) 
			throw FileOpenError((*vimCfg).c_str());

			fin.seekg(BufferSize,std::ios_base::beg);			

		if (fin.fail()) 
			throw FileSeekError((*vimCfg).c_str());
			
			getline(fin,*vimBuf);
			mode = warn.compare(11,7,(*vimBuf).c_str(),0,7);

		if (!mode) {    
			fin.close();  
			E->Quit(msg0.c_str(),"vicom has been previously installed...!\n"
			"\tTo remove vicom or re-install, copy $HOME/vimrc.bak to $HOME/.vimrc\n"
			"\talso remove all vicom aliases from your shell configuration file[s].\n");
			}  
			fin.close();  
			FileCopy(*vimCfg,*vimDir);
			}						 			
		
return 0;
}

//--------------------------------------------------------------------------------
//		CreateVimBuffer: 
//		Create the r/w buffer at start of $HOME/.vimrc
//--------------------------------------------------------------------------------
int XYinstall::CreateVimBuffer() {
Error <string>E;	
auto_ptr<string> vimBuf(new string);
auto_ptr<string> vimCfg(new string(_HomeDir));
auto_ptr<string> vimDir(new string(_HomeDir));
std::ofstream fout;      
std::ifstream fin; 	    


			(*vimDir).append("/vimrc.bak");
			(*vimCfg).append("/.vimrc");

		 	fin.open((*vimDir).c_str(),std::ios_base::in);   	  

		if (fin.fail()) 
			throw FileOpenError((*vimDir).c_str());
		
			fout.open((*vimCfg).c_str(),std::ios_base::out|std::ios_base::trunc);  

		if (fin.fail()) 
			throw FileOpenError((*vimCfg).c_str());

			(*vimBuf).append(BufferOffset,' ');
			fout << (*vimBuf).c_str() << std::flush;
			fout << "\n" << warn << "\n";             
			fout << "\n" << wspce << "\n" << std::flush;   

	  while (getline(fin,*vimBuf))
			fout << (*vimBuf).c_str() << "\n" << std::flush;
			fin.close(); 

		if (!fout.eof()){
			fout.flush();
			fout.close();

		} else {

			fout.close();  
			E->Quit("r/w buffer failed on ",(*vimCfg).c_str(),"\n\n");
			}
			E->Mesg("-- Added r/w buffer to ",(*vimCfg).c_str()," --");		

return 0;
}



//--------------------------------------------------------------------------------
//		Which:   function(not a class member)
//		Returns the env path to executable file or script
//--------------------------------------------------------------------------------
string  Which(const string &fname) {
Error <string> E;	
struct stat statbuf;
auto_ptr<string> path(new string);
string::size_type index = 0;

			if(getenv("PATH") == NULL) {
				E->Quit("Unable to obtain environment Path \n\n");
			} else {
				*path = getenv("PATH");
                }  
                (*path).append("/");    
        while (index != string::npos){
                index = (*path).find(":");
            if (index != string::npos) {
                (*path).replace(index,1,"/ ");
                }
            }     
                istringstream instr(*path);
        while (instr >> *path) {
                (*path).append(fname);
            if (stat((*path).c_str(),&statbuf)<0) {
                continue;
            } else {   
                return((*path).c_str());
                break;
                }
            }
				*path="";
				return((*path).c_str());

}

//--------------------------------------------------------------------------------
//		WriteVimAlias
//		Selects the the $HOME/config files
//--------------------------------------------------------------------------------
void XYinstall::WriteVimAlias(){
std::vector<std::string>vec;

			vec.insert(vec.end(),"/.cshrc");	    
			vec.insert(vec.end(),"/.tcshrc"); 	  
			vec.insert(vec.end(),"/.zshrc");  	  
			vec.insert(vec.end(),"/.bashrc");     
			vec.insert(vec.end(),"/.kshrc");  
   			for_each(vec.begin(),vec.end(),&Getalias); 

}	
	

//--------------------------------------------------------------------------------
//		Getalias:    function(not a class member)  
//		Writes vim and-or gvim aliases to $HOME/config files
//--------------------------------------------------------------------------------
void Getalias(std::string &RcFile) {     
Error <string>E;    							 
struct passwd *pw;
struct stat statbuf;
std::string VimAlias,GvimAlias;
auto_ptr<unsigned>   pos(new unsigned);
auto_ptr<string>    gdir(new string);
auto_ptr<string>    vdir(new string);
bool isVim  = false;
bool isGvim = false;


			*gdir = Which("gvim");
			*vdir = Which("vim");
			
		if(stat((*vdir).c_str(), &statbuf)==0) {
			isVim = true;
			}                                   
		if(stat((*gdir).c_str(), &statbuf)==0) {
			isGvim = true;
			}
			
		if (!(pw = getpwuid(getuid()))) {
			E->Quit("Failed to obtain directory path\n\n");
			}   
            endpwent();                           
            RcFile.insert(0,pw->pw_dir);    

        if (stat(RcFile.c_str(),&statbuf)<0){      
            ;                                    
		} else {
            *pos = RcFile.find("cshrc");

         if (*pos != std::string::npos) {
             VimAlias="alias vi 'vicom -m vim -- '";        
             GvimAlias="alias gvim 'vicom -m gvim -- '";     
             } else {
             VimAlias="alias vi='vicom -mvim -- '";            
			 GvimAlias="alias gvim='vicom -mgvim -- '";     
             }                                              

			std::ofstream fout(RcFile.c_str(),std::ios_base::out|std::ios_base::app);
		 if (!fout) {
			 E->Quit("Unable to open file ",RcFile.c_str(),"\n\n");
		 }

		if (isVim) {
            fout << "\n" << VimAlias  << "    # alias added by vcominst\n" << std::flush;
			E->Mesg("-- Added vi alias to   ",RcFile.c_str()," --");
            } else {
			E->Mesg("-- Warning: vim alias not installed in  ",	RcFile.c_str()," --");
            }

		if (isGvim) {
            fout << GvimAlias  <<         " # alias added by vcominst\n" << std::flush;
			E->Mesg("-- Added gvim alias to ",RcFile.c_str()," --");
            } else {
			E->Mesg("-- Warning: gvim alias not installed in  -- ",
			RcFile.c_str());
            }

			fout.close();
		if (!fout.good()){
			E->Quit("File error occurred with ",RcFile.c_str(),"\n\n");
		}
		}	
}


//--------------------------------------------------------------------------------
//		FileCopy:
//		Creates a backup of the $HOME/.vimrc file
//		Only create a  backup if backup does NOT exist
//--------------------------------------------------------------------------------
void XYinstall::FileCopy(std::string &InFile,std::string &OutFile) {
Error <string> E;
struct stat statbuf;
auto_ptr<string> BakFile(new string(OutFile));
auto_ptr<string> InpFile(new string(InFile));
auto_ptr<string> Sdirs(new string);

			if (stat((*InpFile).c_str(),&statbuf)<0) 
				E->Quit("--",(*InpFile).c_str()," doesn't exist --\n");
				
			if (stat((*BakFile).c_str(),&statbuf)<0) { 

				ifstream fin((*InpFile).c_str(),ios_base::in);

			if (!fin)
				throw FileOpenError((*InpFile).c_str());

				ofstream fout((*BakFile).c_str(),ios_base::out);

			if (!fout){
				fin.close();  
				throw FileCreateError((*BakFile).c_str());
				}

			do {  
				getline(fin,*Sdirs);
				fout << *Sdirs << endl;
				
			if (!fin.eof() && (fin.fail() || fin.bad())) {
				fin.close();
				throw FileReadError((*InpFile).c_str());
				break;
				}

			if (!fout.good()){
				throw FileWriteError((*BakFile).c_str());
				break;
				}

			} while (!fin.eof());  
				fout.clear();
				fout.close();
			if (!fout.good()){
				throw FileCloseError((*BakFile).c_str());
				}
			    fin.clear();
				fin.close(); 
			if (!fin.good()){
				throw FileCloseError((*InpFile).c_str());
				}
			} else {
				E->Mesg("-- Cannot create ",(*BakFile).c_str()," exists --");
				return;
			}

}

} //ns
